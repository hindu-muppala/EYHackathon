
#← Previous Chapters Next →

# logic ----

# except the main files...

# save the remaining file Connect

# in the File

PATH = r'C:\Users\DELL\application\techathon\Dataset'

import os

for folder in os.listdir(PATH):

    if not  os.path.isdir(os.path.join(PATH, folder)):
        
        continue

    for file in os.listdir(os.path.join(PATH, folder)):

        if file.endswith('.txt'):

            with open(os.path.join(PATH, folder, file), 'r', encoding='utf-8') as f:

                data = f.read()

                x = data.split(' ')

                j  = 0

                for i in range(len(x)):

                    
# ← Previous Chapters Next →
# 632 comments
# View all comments →

                    if i+9 < len(x) and x[i+8] == 'all' and x[i+9] == 'comments' and x[i+7][-1:-5:-1] == 'weiV': 

                        j = i

                        break
                
                x = x[:j]

                data = ' '.join(x)

                x = None

                with open(os.path.join(PATH, folder, file), 'w', encoding='utf-8') as f:

                    f.write(data)

                    data = None

                
                    






